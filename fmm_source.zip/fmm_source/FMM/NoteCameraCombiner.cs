﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NAudio.Midi;

namespace FMM
{
    internal static class NoteCameraCombiner
    {
        public static void CombineFiles(string notesFilePath, string cameraFilePath, string outputFilePath)
        {
            // Read notes.json
            JObject notesJson = JObject.Parse(File.ReadAllText(notesFilePath));

            // Read camera.txt
            List<int> cameraEvents = new List<int>(Array.ConvertAll(File.ReadAllLines(cameraFilePath), int.Parse));

            // Update mustHitSection based on camera.txt
            JArray notesSections = (JArray)notesJson["song"]["notes"];
            for (int i = 0; i < notesSections.Count; i++)
            {
                if (i < cameraEvents.Count)
                {
                    notesSections[i]["mustHitSection"] = cameraEvents[i] == 1;
                }
            }

            // Save updated notes.json to chart.json
            File.WriteAllText(outputFilePath, notesJson.ToString(Formatting.Indented));

            // Apply ChartPostfix logic
            ChartPostfix.FixChart(outputFilePath);
        }
    };
}