using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NAudio.Midi;

namespace FMM
{
    internal class Program
    {
        private static void ResetGlobals()
        {
            Globals.ppqn = 96;
            Globals.name = "";
            Globals.bpm = 0f;
            Globals.needsVoices = 0;
            Globals.player1 = "";
            Globals.player2 = "";
        }

        [STAThread]
        private static void Main(string[] args)
        {

            Console.Title = "FMM v3";
            Console.WriteLine("Funkin' MIDI Mapper [version 3.0]");
            Console.WriteLine("Created by BobbyDX_\n");
            Console.WriteLine("Select mode:\n1. MIDI to FNF JSON\n2. Combine FNF Charts\n3. Assign Psych Engine Notetypes\n4. FNF to MIDI");
            string modeSelection = Console.ReadLine();

            switch (modeSelection)
            {
                case "1":
                    RunMonoForm(args);
                    break;

                case "2":
                    RunPolyForm(args);
                    break;

                case "3":
                    RunAssign4pmMode(args);
                    break;

                case "4":
                    RunFNFtoMIDIMode(args);
                    break;

                default:
                    Console.WriteLine("Invalid selection. Exiting program.");
                    return;
            }
        }

        // MonoForm Logic
        private static void RunMonoForm(string[] args)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                InitialDirectory = Directory.GetCurrentDirectory(),
                Filter = "MIDI file (*.mid)|*.mid|All files (*.*)|*.*",
                Multiselect = true
            };

            if (args.Length == 0)
            {
                Console.WriteLine("Select your .mid file...");
            }

            if (args.Length != 0 || openFileDialog.ShowDialog() == DialogResult.OK)
            {
                if (args.Length == 0)
                {
                    args = openFileDialog.FileNames;
                }

                string initialDirectory = Directory.GetCurrentDirectory();
                string[] inputFiles = args;

                foreach (string inputFile in inputFiles)
                {
                    try
                    {
                        var midiFile = new MidiFile(inputFile, false);
                        List<MidiEvent> midiEvents = midiFile.Events.SelectMany(track => track).ToList();

                        Console.Write("Enter BPM: ");
                        float bpm = float.Parse(Console.ReadLine());

                        Console.Write("Song name: ");
                        string songName = Console.ReadLine();

                        Console.Write("Needs voice file? (y/N, default y): ");
                        int needsVoices = (Console.ReadLine().ToLower().Trim() != "n") ? 1 : -1;

                        Console.Write("Enter the playable character (e.g., 'bf'): ");
                        string player1 = Console.ReadLine();

                        Console.Write("Enter the opponent character (e.g., 'dad'): ");
                        string player2 = Console.ReadLine();

                        // Asking if they want to assign a custom GF skin
                        string gfVersion = null;
                        Console.Write("Do you want to assign a custom GF skin? (y/N, default N): ");
                        if (Console.ReadLine().ToLower().Trim() == "y")
                        {
                            Console.Write("Enter the custom GF version (e.g., 'gf-neo'): ");
                            gfVersion = Console.ReadLine();
                        }

                        Console.Write("Scroll speed: ");
                        float speed = float.Parse(Console.ReadLine());

                        // Generate the JSON object
                        JObject songJson = NoteGenerator.MidiToJSON(midiEvents, bpm, songName, needsVoices, player1, player2, speed);

                        // If GF skin was assigned, add it to the JSON
                        if (!string.IsNullOrEmpty(gfVersion))
                        {
                            songJson["gfVersion"] = gfVersion;
                        }

                        string outputDirectory = Path.Combine(initialDirectory, songName);
                        Directory.CreateDirectory(outputDirectory);

                        string notesFilePath = Path.Combine(outputDirectory, "notes.json");
                        File.WriteAllText(notesFilePath, songJson.ToString(Formatting.Indented));
                        Console.WriteLine("---Generated base note chart.---");

                        FunkinCam.GenerateCameraFile(midiEvents, bpm, Path.Combine(outputDirectory, "camera.txt"));
                        string cameraFilePath = Path.Combine(outputDirectory, "camera.txt");
                        Console.WriteLine("---Generated camera text file.---");

                        // Combine files to create chart.json
                        NoteCameraCombiner.CombineFiles(notesFilePath, cameraFilePath, Path.Combine(outputDirectory, "chart.json"));
                        string chartFilePath = Path.Combine(outputDirectory, "chart.json");
                        Console.WriteLine("---Combined files to produce chart.json.---");

                        // Ask if the user wants to delete remnants
                        while (true)
                        {
                            Console.Write("Delete chart remnants? (1 for Yes, 0 for No): ");
                            string input = Console.ReadLine();
                            if (input == "1")
                            {
                                File.Delete(notesFilePath);
                                File.Delete(cameraFilePath);
                                Console.WriteLine("Deleted notes.json and camera.txt.");
                                break;
                            }
                            else if (input == "0")
                            {
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Invalid input. Please enter 1 or 0.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        return;
                    }
                }

                ResetGlobals();
                Console.WriteLine("Press any key to close...");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Dialog closed");
            }
        }

        // PolyForm Logic
        private static void RunPolyForm(string[] args)
        {
            Console.WriteLine("You selected PolyForm. You can combine a base FNF chart with up to 4 additional charts.");

            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                InitialDirectory = Directory.GetCurrentDirectory(),
                Filter = "FNF JSON chart (*.json)|*.json|All files (*.*)|*.*",
                Multiselect = false
            };

            // Select the base FNF chart
            Console.WriteLine("Select the base FNF chart...");
            JObject baseChart = null;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string baseChartPath = openFileDialog.FileName;
                baseChart = JObject.Parse(File.ReadAllText(baseChartPath));

                // Now handle additional charts (1 to 4 additional charts)
                int numberOfAdditionalCharts = GetNumberOfAdditionalCharts();
                List<JObject> additionalCharts = new List<JObject>();

                for (int i = 0; i < numberOfAdditionalCharts; i++)
                {
                    Console.WriteLine($"Select additional FNF chart {i + 1}...");
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string additionalChartPath = openFileDialog.FileName;
                        JObject additionalChart = JObject.Parse(File.ReadAllText(additionalChartPath));
                        additionalCharts.Add(additionalChart);
                    }
                }

                // Combine the additional charts with the base chart
                CombineCharts(baseChart, additionalCharts);

                // Save the resulting chart
                Console.WriteLine("Select output directory to save the final chart.");
                using (FolderBrowserDialog folderBrowser = new FolderBrowserDialog())
                {
                    if (folderBrowser.ShowDialog() == DialogResult.OK)
                    {
                        string outputDirectory = folderBrowser.SelectedPath;
                        string finalChartPath = Path.Combine(outputDirectory, "combined_chart.json");
                        File.WriteAllText(finalChartPath, baseChart.ToString(Formatting.Indented));
                        Console.WriteLine($"Final chart saved to {finalChartPath}");
                    }
                }
            }
        }

        // New Mode: Assign4pmMode
        private static void RunAssign4pmMode(string[] args)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                InitialDirectory = Directory.GetCurrentDirectory(),
                Filter = "FNF JSON chart (*.json)|*.json|All files (*.*)|*.*",
                Multiselect = false
            };

            Console.WriteLine("Select the FNF chart to which you'd like to assign a 4pm value...");
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string chartPath = openFileDialog.FileName;
                JObject chart = JObject.Parse(File.ReadAllText(chartPath));

                Console.Write("Enter the 4th parameter (4pm) value to assign to all notes: ");
                string chart4pm = Console.ReadLine();

                // Assign 4pm value to all notes in the chart
                Add4pmToChart(chart, chart4pm);

                // Save the updated chart
                SaveChartWith4pm(chart);
            }
            else
            {
                Console.WriteLine("No chart selected.");
            }
        }

        // Helper to add the 4pm to each note in the chart
        private static void Add4pmToChart(JObject chart, string chart4pm)
        {
            JArray sections = (JArray)chart["song"]["notes"];

            if (sections != null)  // Check if sectionNotes exists
            {
                foreach (JObject section in sections)
                {
                    JArray sectionNotes = (JArray)section["sectionNotes"];
                    if (sectionNotes != null)  // Check if sectionNotes exists in the section
                    {
                        foreach (JArray note in sectionNotes)
                        {
                            if (note != null && note.Count == 3)  // Check if note is valid and has 3 elements (time, note ID, duration)
                            {
                                note.Add(chart4pm); // Append the 4pm value (as text) to each note
                            }
                        }
                    }
                }
                Console.WriteLine("4pm value assigned to all notes.");
            }
            else
            {
                Console.WriteLine("Error: 'sectionNotes' is null or missing from the chart.");
            }
        }

        // Helper to save the chart with the assigned 4pm values
        private static void SaveChartWith4pm(JObject chart)
        {
            using (FolderBrowserDialog folderBrowser = new FolderBrowserDialog())
            {
                Console.WriteLine("Select the output directory to save the updated chart...");
                if (folderBrowser.ShowDialog() == DialogResult.OK)
                {
                    string outputDirectory = folderBrowser.SelectedPath;
                    string finalChartPath = Path.Combine(outputDirectory, "chart_with_4pm.json");
                    File.WriteAllText(finalChartPath, chart.ToString(Formatting.Indented));
                    Console.WriteLine($"Updated chart saved to {finalChartPath}");
                }
                else
                {
                    Console.WriteLine("No output directory selected.");
                }
            }
        }

        // Helper to get the number of additional charts (1-4)
        private static int GetNumberOfAdditionalCharts()
        {
            int numberOfCharts;
            while (true)
            {
                Console.Write("How many additional charts would you like to add? (1 to 4): ");
                if (int.TryParse(Console.ReadLine(), out numberOfCharts) && numberOfCharts >= 1 && numberOfCharts <= 4)
                {
                    break;
                }
                Console.WriteLine("Invalid number. Please choose between 1 and 4.");
            }
            return numberOfCharts;
        }

        // Helper to combine additional charts into the base chart, matching section by section
        private static void CombineCharts(JObject baseChart, List<JObject> additionalCharts)
        {
            JArray baseSections = (JArray)baseChart["song"]["notes"];

            if (baseSections == null)
            {
                Console.WriteLine("Error: 'sectionNotes' is null or missing from the base chart.");
                return;
            }

            foreach (var additionalChart in additionalCharts)
            {
                JArray additionalSections = (JArray)additionalChart["song"]["notes"];

                if (additionalSections == null)
                {
                    Console.WriteLine("Error: 'sectionNotes' is null or missing from an additional chart.");
                    continue;  // Skip this chart and move to the next
                }

                // Loop through each section and add the additional notes to the base chart
                for (int i = 0; i < baseSections.Count; i++)
                {
                    JArray baseSectionNotes = (JArray)baseSections[i];

                    if (i < additionalSections.Count)
                    {
                        JArray additionalSectionNotes = (JArray)additionalSections[i];

                        if (baseSectionNotes == null || additionalSectionNotes == null)
                        {
                            Console.WriteLine($"Error: A section in either the base or additional chart is null at index {i}.");
                            continue;
                        }

                        // Add all notes from the additional chart's section to the base section
                        foreach (JArray note in additionalSectionNotes)
                        {
                            if (note == null)
                            {
                                Console.WriteLine("Error: A note in the additional chart is null.");
                                continue;
                            }

                            baseSectionNotes.Add(note); // Add the note to the base section
                        }
                    }
                }
            }
        }

        private static void MidiDecodeGen()
        {
            Console.Write("Enter the chart file path (notes.json): ");
            string notesFilePath = Console.ReadLine();

            if (File.Exists(notesFilePath))
            {
                string tempFilePath = Path.Combine(Path.GetDirectoryName(notesFilePath), "temp_notes.json");
                File.Copy(notesFilePath, tempFilePath, true);

                ChartPostfix.FixChart(tempFilePath);

                JObject chartJson = JObject.Parse(File.ReadAllText(tempFilePath));
                JArray notesSections = (JArray)chartJson["song"]["notes"];

                List<JObject> midiNotes = new List<JObject>();

                foreach (JObject section in notesSections)
                {
                    section["mustHitSection"] = true;

                    JArray sectionNotes = (JArray)section["sectionNotes"];
                    foreach (JArray noteArray in sectionNotes)
                    {
                        double time = noteArray[0].Value<double>() / 1000.0;
                        int pitch = noteArray[1].Value<int>() % 12; // Mod 12 to keep pitch within MIDI range
                        int velocity = 127; // Default velocity
                        double duration = noteArray[2].Value<double>() / 1000.0; // Convert duration to seconds

                        JObject midiNote = new JObject
                        {
                            ["time"] = time,
                            ["pitch"] = pitch,
                            ["velocity"] = velocity,
                            ["duration"] = duration
                        };

                        midiNotes.Add(midiNote);
                    }
                }

                JObject midiJson = new JObject
                {
                    ["bpm"] = chartJson["song"]["bpm"],
                    ["notes"] = JArray.FromObject(midiNotes)
                };

                string midiJsonFilePath = Path.Combine(Path.GetDirectoryName(notesFilePath), "midi_convert.json");
                File.WriteAllText(midiJsonFilePath, midiJson.ToString());

                Console.WriteLine("Reverse function completed. MIDI conversion file saved as midi_convert.json.");
                Console.WriteLine("Press any key to close...");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("The specified file does not exist.");
            }
        }


        private static void MidiForm()
        {
            Console.WriteLine("Enter the path to the reverseFunction JSON file:");
            string jsonFilePath = Console.ReadLine();

            if (!File.Exists(jsonFilePath))
            {
                Console.WriteLine("File does not exist.");
                return;
            }

            // Read JSON file
            string jsonContent = File.ReadAllText(jsonFilePath);
            JObject jsonObject = JObject.Parse(jsonContent);

            // Extract BPM
            float bpm = jsonObject["bpm"].Value<float>();

            // Extract notes
            JArray notesArray = (JArray)jsonObject["notes"];
            List<MidiEvent> midiEvents = new List<MidiEvent>();

            int ppqn = 96; // Pulses per quarter note

            foreach (JObject noteObject in notesArray)
            {
                double timeInSeconds = noteObject["time"].Value<double>();
                int pitch = noteObject["pitch"].Value<int>();
                int velocity = noteObject["velocity"].Value<int>();
                double durationInSeconds = noteObject["duration"].Value<double>();

                double ticksPerSecond = (ppqn * bpm) / 60.0;
                long absoluteTime = (long)(timeInSeconds * ticksPerSecond);
                int noteLength = (int)(durationInSeconds * ticksPerSecond);

                // Note on event
                midiEvents.Add(new NoteOnEvent(absoluteTime, 1, pitch, velocity, noteLength));
                // Note off event
                midiEvents.Add(new NoteEvent(absoluteTime + noteLength, 1, MidiCommandCode.NoteOff, pitch, 0));
            }

            // Create MIDI file
            string midiFilePath = Path.Combine(Path.GetDirectoryName(jsonFilePath), "output.mid");
            MidiEventCollection midiEventCollection = new MidiEventCollection(1, ppqn);
            midiEventCollection.AddTrack(midiEvents);

            MidiFile.Export(midiFilePath, midiEventCollection);
            Console.WriteLine("MIDI file created: " + midiFilePath);
        }
        private static void RunTestOption()
        {
            Console.WriteLine("TestOption mode selected.");
            Console.WriteLine("This is a placeholder for future functionality.");
        }

        // New FNF-to-MIDI Mode with Submodes
        private static void RunFNFtoMIDIMode(string[] args)
        {
            Console.WriteLine("Select submode:\n1. Decode FNF to MIDI JSON\n2. Encode MIDI JSON data to MIDI File");
            string submodeSelection = Console.ReadLine();

            switch (submodeSelection)
            {
                case "1":
                    MidiDecodeGen();
                    break;

                case "2":
                    MidiForm();
                    break;

                default:
                    Console.WriteLine("Invalid submode selection. Exiting program.");
                    return;
            }
        }
    }
}