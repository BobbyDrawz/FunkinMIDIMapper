namespace FMM
{
    public enum MIDINotes
    {
        BF_L = 48,
        BF_D = 49,
        BF_U = 50,
        BF_R = 51,
        BF_CAM = 53,
        EN_CAM = 54,
        BPM_CH = 56,
        ALT_AN = 57,
        EN_L = 60,
        EN_D = 61,
        EN_U = 62,
        EN_R = 63
    }
}
