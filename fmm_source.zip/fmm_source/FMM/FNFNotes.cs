namespace FMM
{
    public enum FNFNotes
    {
        F_L,
        F_D,
        F_U,
        F_R,
        O_L,
        O_D,
        O_U,
        O_R,
        BF_CAM,
        EN_CAM,
        ALT_AN,
        BPM_CH
    }
}
